const { newResult } = require('./utils');
const util = require('util');
const { ipcMain, Menu, Tray, dialog } = require('electron');
const fs = require('fs');
const applicationBootstrap = require('./voltmxApplicationApiBootstrap');
const { defaultContextMenuTemplate, mergeTemplates } = require('./contextMenu.js');

var voltmxTray;
let win;

function volmxApplicationHandlers(context) {

    win = context.win;
    function updateMenuClickFunctions(template) {
        // We use stringify both to replace the functions.
        const tempString = JSON.stringify(template); 
        return JSON.parse(tempString, (key, value) => {
            if (key === 'click') {
                return menuClickFunction;
            }
            return value;
        });
    }

    function menuClickFunction(menuitem, browserWindow, evt) {
        console.log(`Application handler menuClick ${menuitem.label}, ${menuitem.id}, ${menuitem.role}`);
        const mItem = {};
        mItem.label = menuitem.label;
        mItem.id = menuitem.id;
        mItem.role = menuitem.role;

        if (browserWindow && browserWindow.webContents) {
            browserWindow.webContents.send(applicationBootstrap.channel_application_menuClicked, mItem);
        } else {
            if (win !== null && !win.isDestroyed()) {
                win.restore();
                setTimeout(() => {
                    win.webContents.send(applicationBootstrap.channel_application_menuClicked, mItem);
                })
            }
        }
    }

    function getParentOfMenuItemWithIdOrLabel(aMenu, id) {
        const checkItems = aMenu.items ? aMenu.items : aMenu.submenu?.items;
        if (checkItems) {
            for (let i = 0; i < checkItems.length; i++) {
                const currentItem = checkItems[i];
                if (id === currentItem.id || id === currentItem.label) {
                    return aMenu.submenu ? aMenu.submenu : aMenu;
                } else {
                    // If the parent is found in the nested items of this item, return the parent...no need to continue
                    nItem = getParentOfMenuItemWithIdOrLabel(currentItem, id);
                    if (nItem) {
                        return nItem;
                    }
                }
            }
        }
        return undefined;
    }

    function getShallowMenuItemPositionWithIdOfLabel(aMenu, id) {
        const checkItems = aMenu.items ? aMenu.items : aMenu.submenu?.items;
        if (checkItems) {
            for (let i = 0; i < checkItems.length; i++) {
                const currentItem = checkItems[i];
                if (id === currentItem.id || id === currentItem.label) {
                    return i;
                }
            }
        }
        return undefined;
    }

    function getMenuItemByIdOrLabel(aMenu, id) {
        const checkItems = aMenu.items ? aMenu.items : aMenu.submenu?.items;
        if (checkItems) {
            for (let i = 0; i < checkItems.length; i++) {
                const currentItem = checkItems[i];
                if (id === currentItem.id || id === currentItem.label) {
                    return currentItem;
                } else {
                    // If the menuitem is found in the nested items of this item, return the menuitem...no need to continue
                    nItem = getMenuItemByIdOrLabel(currentItem, id);
                    if (nItem) {
                        return nItem;
                    }
                }
            }
        }
        return undefined;
    }

    function removeMenuItemByIdOrLabel(aMenu, id) {
        const checkItems = aMenu.items ? aMenu.items : aMenu.submenu?.items;
        if (checkItems) {
            for (let i = 0; i < checkItems.length; i++) {
                const currentItem = checkItems[i];
                if (id === currentItem.id || id === currentItem.label) {
                    // Remove the item from the current menu items and return that the item was found.  No need to continue
                    checkItems.splice(i, 1);
                    return true;
                } else {
                    // If the item is found in the nested items of this item, return true...no need to continue
                    if (removeMenuItemByIdOrLabel(currentItem, id) === true) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    function destroyTray() {
        if (voltmxTray) {
            voltmxTray.destroy();
            voltmxTray = undefined;
        }
    }

    function getApplicationMenu() {
        console.debug("In getApplicationMenu");
        const result = newResult();
        try {
            const menuItems = Menu.getApplicationMenu()?.items.map(item => {return item.label}) ?? 'Menu is empty';
            result.value = `${util.inspect(menuItems, false, 5)}`;
        } catch (err) {
            console.error(err);
            result.error = {};
            result.error.errorMessage = err.errorMessage;
        }
        return result
    }

    ipcMain.on(applicationBootstrap.channel_application_getAppMenu,  (event, args) => {
        console.debug(`on ${applicationBootstrap.channel_application_getAppMenu}`);
        event.returnValue = getApplicationMenu();
    })

    ipcMain.on(applicationBootstrap.channel_application_bootstrap,  (event, args) => {
        event.returnValue = applicationBootstrap;
    })

    // removeHandler is needed prior to ipcMain.handle because there is an electron bug when trying to register a handler twice.  It 
    // becomes obvious when closing the application menu on a mac and clicking on the app bar application icon again.
    ipcMain.removeHandler(applicationBootstrap.channel_application_getAppMenu);
    ipcMain.handle(applicationBootstrap.channel_application_getAppMenu,  (event, args) => {
        console.debug(`handle ${applicationBootstrap.channel_application_getAppMenu}`);
        return getApplicationMenu();
    })


    ipcMain.removeHandler(applicationBootstrap.channel_application_createAppMenu);
    ipcMain.handle(applicationBootstrap.channel_application_createAppMenu,  (event, template) => {
        console.debug(`handle ${applicationBootstrap.channel_application_createAppMenu}`);
        const result = newResult();
        try {
            if (template === undefined || template === '' || template === null) {
                result.error = new Error(`Could not create app menu item since template is undefined/null/empty.`);
                return result;
            }

            const mTemplate = updateMenuClickFunctions(template);
            const menu = Menu.buildFromTemplate(mTemplate)
            Menu.setApplicationMenu(menu)
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.removeHandler(applicationBootstrap.channel_application_insertAppMenuItem);
    ipcMain.handle(applicationBootstrap.channel_application_insertAppMenuItem,  (event, template, id, position) => {
        console.debug(`handle ${applicationBootstrap.channel_application_insertAppMenuItem}`);
        const result = newResult();
        try {
            if (id === undefined || id === '' || id === null || template === undefined || template === '' || template === null) {
                result.error = new Error(`Could not insert app menu item since id/template is undefined/null/empty.`);
                return result;
            }

            let currentMenu = Menu.getApplicationMenu();
            let relativePosition;
            let parentMenu;
            if (currentMenu && id !== undefined) {
                parentMenu = getParentOfMenuItemWithIdOrLabel(currentMenu, id);
                if(parentMenu){
                    relativePosition = getShallowMenuItemPositionWithIdOfLabel(parentMenu, id);
                } else {
                    result.error = new Error(`Sibling menu/submenu item with id '${id}' not found.`);
                    return result;
                }
            }

            const mTemplate = updateMenuClickFunctions(template);
            const insertMenu = Menu.buildFromTemplate(mTemplate);
            if (insertMenu) {
                if (parentMenu) {
                    if (relativePosition !== undefined) {
                        const insertPos = (position === 'before') ? relativePosition : relativePosition + 1;
                        // parentMenu.insertMenu(insertPos, insertMenu);
                        for (let i = insertMenu.items.length - 1; i >= 0; i--) {
                            parentMenu.insert(insertPos, insertMenu.items[i]);
                        }
                    } else {
                        // parentMenu.append(insertMenu);
                        for (let i = 0; i < insertMenu.items.length; i++) {
                            parentMenu.append(insertMenu.items[i]);
                        }
                    }
                    // for (let i = 0; i < insertMenu.items.length; i++) {
                    //     currentMenu.append(insertMenu.items[i]);
                    // }
                } else {
                    currentMenu = insertMenu;
                }
                Menu.setApplicationMenu(currentMenu);
                result.value = true;
            } else {
                result.error = new Error("No menu could be created to insert.")
                return result;
            }
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.removeHandler(applicationBootstrap.channel_application_deleteAppMenuItem);
    ipcMain.handle(applicationBootstrap.channel_application_deleteAppMenuItem,  (event, id) => {
        console.debug(`handle ${applicationBootstrap.channel_application_deleteAppMenuItem}`);
        const result = newResult();
        try {
            if (id === undefined || id === '' || id === null) {
                result.error = new Error(`Could not delete app menu item since id is undefined/null/empty.`);
                return result;
            }

            let currentMenu = Menu.getApplicationMenu();
            if (currentMenu && id !== undefined) {
                const removeItem = getMenuItemByIdOrLabel(currentMenu, id);
                if (removeItem) {
                    // Remove the target item
                    removeMenuItemByIdOrLabel(currentMenu, id);

                    // Create the new template
                    // Need to store off functions as we're stringifying...
                    let funCount = 0;
                    const funMap = new Map();
                    const template = JSON.stringify(currentMenu.items, (field, value) => {
                        if (field === 'menu' || field === 'commandsMap' || field === 'commandId' || value === null || value === "") {
                            return undefined;
                        } else if (field === 'submenu') {
                            console.log(value);
                            return value["items"];
                        } else if (field === 'click' && typeof(value) === 'function') {
                            const key = `com.hcl.voltmx.functionKey${funCount++}`;
                            funMap.set(key, value);
                            return key;
                        } else {
                            return value;
                        }
                    });

                    // Create and set the new menu
                    // Replace any functions from the funMap
                    const newMenu = Menu.buildFromTemplate(JSON.parse(template, (field, value) => {
                        if (field === 'click' && typeof(value) === 'string') {
                            const fun = funMap.get(value);
                            return fun === undefined ? value : fun;
                        } else {
                            return value;
                        }
                    }));
                    Menu.setApplicationMenu(newMenu);
                } else {
                    result.error = new Error(`Sibling menu/submenu item with id '${id}' not found.`);
                    return result;
                }
                result.value = true;
            }
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    let currentContextMenuTemplate = [...defaultContextMenuTemplate];
    let isDefaultDeleted = false;
    
    ipcMain.removeHandler(applicationBootstrap.channel_application_removeContextMenuItems);
    /**
     * Handles the removal of specific items from the context menu.
     *
     * @param {Object} event - The IPC event.
     * @param {Array|string} deleteItems - The labels of the items to delete from the context menu.
     * @returns {Object} result - An object containing the result of the operation.
     * If successful, result.value is set to true.
     * If an error occurs, result.error contains the error message.
     *
     * @description
     * This IPC handler listens for requests to remove specific items from the context menu.
     * It verifies if the items to be deleted exist in the current context menu template.
     * If all items are found, it updates the context menu template by removing the specified items.
     * An event listener for the 'context-menu' event is added to the `webContents`, which pops up the updated context menu when triggered.
     * Any errors encountered during this process are caught and included in the result object.
     */
    ipcMain.handle(applicationBootstrap.channel_application_removeContextMenuItems, (event, deleteItems) => {
        console.debug(`handle ${applicationBootstrap.channel_application_removeContextMenuItems}`);
        const result = newResult();
        try {
            const itemsToDelete = Array.isArray(deleteItems) ? deleteItems : [deleteItems];
            let itemNotFound = false;
            itemsToDelete.forEach(item => {
                if (!currentContextMenuTemplate.some(menuItem => menuItem.label === item)) {
                    itemNotFound = true;
                }
            });
            if (!itemNotFound) {
                const updatedContextMenuTemplate = currentContextMenuTemplate.filter(item => !itemsToDelete.includes(item.label));
                currentContextMenuTemplate = updatedContextMenuTemplate; // Update the current context menu template
                const mTemplate = updateMenuClickFunctions(updatedContextMenuTemplate);
                const contextMenu = Menu.buildFromTemplate(mTemplate);  
                win.webContents.removeAllListeners('context-menu');
                win.webContents.on('context-menu', (e, params) => {
                    e.preventDefault();
                    contextMenu.popup({ window: win, ...params });
                });
                isDefaultDeleted = true;
                result.value = true;
            } else {
                result.error = new Error("One or more menu/submenu item ids marked for deletion were not found in the context menu.");
            }
        } catch (err) {
            result.error = err;
        }
        return result;
    });

    ipcMain.removeHandler(applicationBootstrap.channel_application_removeContextMenu);
    /**
     * Handles the removal of the entire context menu.
     * 
     * @param {Object} event - The IPC event.
     * @returns {Object} result - An object containing the result of the operation.
     * If successful, result.value is set to true.
     * If an error occurs, result.error contains the error message.
     * 
     * @description
     * This IPC handler listens for requests to remove the entire context menu.
     * It clears the current context menu template and removes all 'context-menu' listeners from the `webContents` of the window.
     * Any errors encountered during this process are caught and included in the result object.
     */
    ipcMain.handle(applicationBootstrap.channel_application_removeContextMenu, (event) => {
        console.debug(`handle ${applicationBootstrap.channel_application_removeContextMenu}`);
        const result = newResult();
        try {
            win.webContents.removeAllListeners('context-menu');
            currentContextMenuTemplate = []; // Clear the current context menu template
            isDefaultDeleted = true;
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    });

    ipcMain.removeHandler(applicationBootstrap.channel_application_addContextMenuItems);
    /**
     * Handles the addition of new items to the context menu.
     * 
     * @param {Object} event - The IPC event.
     * @param {Array} template - The template for the new context menu items.
     * @returns {Object} result - An object containing the result of the operation.
     * If successful, result.value is set to true.
     * If an error occurs, result.error contains the error message.
     * 
     * @description
     * This IPC handler listens for requests to add new items to the context menu.
     * It first removes any existing 'context-menu' listeners from the `webContents` of the window.
     * Depending on whether the default template is to be deleted or not, it either uses the new template directly or merges it with the default template.
     * The final template is then used to build the context menu.
     * An event listener for the 'context-menu' event is added to the `webContents`, which pops up the updated context menu when triggered.
     * Any errors encountered during this process are caught and included in the result object.
     */
    ipcMain.handle(applicationBootstrap.channel_application_addContextMenuItems, (event, template) => {
        console.debug(`handle ${applicationBootstrap.channel_application_addContextMenuItems}`);
        const result = newResult();
        try {
            win.webContents.removeAllListeners('context-menu');
            let finalTemplate;
            if (isDefaultDeleted) {
                finalTemplate = template; // use the new template directly
            } else {
                finalTemplate = mergeTemplates(defaultContextMenuTemplate, template); // merge the default template with the new template
            }
            currentContextMenuTemplate = finalTemplate;
            const mTemplate = updateMenuClickFunctions(finalTemplate);
            const contextMenu = Menu.buildFromTemplate(mTemplate);       
            win.webContents.on('context-menu', (e, params) => {
                e.preventDefault();
                contextMenu.popup({ window: win, ...params });
            });
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    });

    ipcMain.removeHandler(applicationBootstrap.channel_application_createTrayItem);
    ipcMain.handle(applicationBootstrap.channel_application_createTrayItem,  (event, iconPath, template, toolTip) => {
        console.debug(`handle ${applicationBootstrap.channel_application_createTrayItem}`);
        const result = newResult();
        try {
            // Verify path to icon exists
            if (!fs.lstatSync(iconPath).isFile()) {
                result.error = new Error(`Could not create the tray item because ${iconPath} is not an icon file.`);
            } else {
                // Register menu clicks and build menu from template
                const mTemplate = updateMenuClickFunctions(template);
                const menu = Menu.buildFromTemplate(mTemplate)

                // Create Tray
                destroyTray();
                voltmxTray = new Tray(iconPath);
                if (toolTip !== undefined && typeof (toolTip === 'string')) {
                    voltmxTray.setToolTip(toolTip);            
                }

                if (menu !== undefined) {
                    voltmxTray.setContextMenu(menu);            
                }
                result.value = true;
            }

        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.removeHandler(applicationBootstrap.channel_application_deleteTrayItem);
    ipcMain.handle(applicationBootstrap.channel_application_deleteTrayItem,  (event) => {
        console.debug(`handle ${applicationBootstrap.channel_application_deleteTrayItem}`);
        const result = newResult();
        try {
            destroyTray();
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.on(applicationBootstrap.channel_application_customAlert, (event, displayMessage, alertType) => {
        console.debug(`on ${applicationBootstrap.channel_application_customAlert}`);
        const result = newResult();
        try {
            var btnNames;
            if(alertType === 'confirmation'){
                btnNames = ['OK', 'Cancel'];
            }else{
                btnNames = ['OK']; 
            }

            const resultValue = dialog.showMessageBoxSync(win, {
                message: `${displayMessage}`,
                buttons: btnNames
            });
            result.value = (resultValue === 0);
        } catch (err) {
            result.error = err;
        }
        event.returnValue = result;
    });

}

function loadAPIHandlers(context)  {
    this.volmxApplicationHandlers(context);
}
module.exports = {volmxApplicationHandlers, loadAPIHandlers};



// preloadapplication.js
console.log("Loading preloadapplication.js");
const { contextBridge, ipcRenderer } = require("electron");

const menuFunctionMap = new Map();

const applicationBootstrap = ipcRenderer.sendSync("com.hcl.voltmx.applicationBootstrap");

function handleError(error, channel) { 
  if (error) {
    const msg = error.errorMessage ?? error.message;
    throw new Error(msg ? msg : `An error occurred in channel ${channel ? channel : 'unknown'}`);
  }
}

function getMenuFunctionKey(menuObject) {
    let key = menuObject.label ? menuObject.label : "";
    key+= "#";
    key += menuObject.id ? menuObject.id : "";
    key+= "#";
    key += menuObject.role ? menuObject.role : "";
    return key;
}

function registerMenuClickFunctions(template) {
    // We use stringify both to replace the functions.
    const tempString = JSON.stringify(template, (key, value) => {
        let retVal = value;
        if (value.click && typeof(value.click) === 'function') {
            retVal = {...value};
            const mKey = getMenuFunctionKey(value);
            menuFunctionMap.set(mKey, value.click);
            retVal.click = mKey;
        }
        return retVal;
    }); 
    return JSON.parse(tempString);
}

contextBridge.exposeInMainWorld("voltmxapplication", {
      application: {
          addMenuClickedListener: function() {
            ipcRenderer.on(applicationBootstrap.channel_application_menuClicked, (evt, menuItem) =>{
                const mFunc = menuFunctionMap.get(getMenuFunctionKey(menuItem));
                if (mFunc) {
                    mFunc();
                } else {
                    console.debug(`Could not find function for menu item clicked: ${menuItem.label}, ${menuItem.id}, ${menuItem.role} `);
                }
            });
          },
          getCurrentSettingsMenu: async function() {
              const channel = applicationBootstrap.channel_application_getAppMenu;
              console.debug(`In ${applicationBootstrap.channel_application_getAppMenu}`);
              const results = await ipcRenderer.invoke(channel);
              handleError(results?.error, channel);
              return results.value;
          },
          createDesktopAppMenu: async function(menuTemplate) {
              const channel = applicationBootstrap.channel_application_createAppMenu;
              console.debug(`In ${channel}`);
              const updatedTemplate = registerMenuClickFunctions(menuTemplate);
              const results = await ipcRenderer.invoke(channel, updatedTemplate);
              handleError(results?.error, channel);
              return results.value;
          },
          deleteDesktopAppMenu: async function() {
              const channel = applicationBootstrap.channel_application_createAppMenu;
              console.debug(`In ${channel}`);
              const results = await ipcRenderer.invoke(channel, []);
              handleError(results?.error, channel);
              return results.value;
          },
          insertDesktopAppMenuItem: async function(menuTemplate, id, position) {
              const channel = applicationBootstrap.channel_application_insertAppMenuItem;
              console.debug(`In ${channel}`);
              const updatedTemplate = registerMenuClickFunctions(menuTemplate);
              const results = await ipcRenderer.invoke(channel, updatedTemplate, id, position);
              handleError(results?.error, channel);
              return results.value;
          },
          deleteDesktopAppMenuItem: async function(menuid) {
              // TODO: Need to remove registered menu functions...will require a call from the main process with the click functions
              const channel = applicationBootstrap.channel_application_deleteAppMenuItem;
              console.debug(`In ${channel}`);
              const results = await ipcRenderer.invoke(channel, menuid);
              handleError(results?.error, channel);
              return results.value;
          },
          /**
           * Adds items to the context menu.
           * @param {Array} menuTemplate - An array of objects that define the context menu items to be added.
           * @return {Promise} - A Promise that resolves to the value returned from the main process.
           * @description
           * This function uses Electron's IPC (Inter-Process Communication) to send a request to the main process to add specified items to the context menu.
           * The IPC channel used is specified in `applicationBootstrap.channel_application_addContextMenuItems`.
           * Any errors that occur during the execution are handled by the `handleError` function.
           */
          addContextMenuItems: async function (menuTemplate) {
              const channel = applicationBootstrap.channel_application_addContextMenuItems;
              console.debug(`In ${channel}`);
              const updatedTemplate = registerMenuClickFunctions(menuTemplate);
              const results = await ipcRenderer.invoke(channel, updatedTemplate);
              handleError(results?.error, channel);
              return results.value;
          },
          /**
           * removes specified items from the context menu.
           *
           * @param {Array} deleteItems - An array of labels of the context menu items to be removed.
           * @return {Promise} - A Promise that resolves to the value returned from the main process.
           *
           * @description
           * This function uses Electron's IPC (Inter-Process Communication) to send a request to the main process to remove specified items from the context menu.
           * The IPC channel used is specified in `applicationBootstrap.channel_application_removeContextMenuItems`.
           * Any errors that occur during the execution are handled by the `handleError` function.
           */
          removeContextMenuItems: async function (deleteItems) {
              const channel = applicationBootstrap.channel_application_removeContextMenuItems;
              console.debug(`In $(applicationBootstrap.channel_application_removeContextMenuItems)`)
              const results = await ipcRenderer.invoke(channel, deleteItems);
              handleError(results?.error, channel);
              return results.value;
          },
          /**
           * removes all items from the context menu.
           * @return {Promise} - A Promise that resolves to the value returned from the main process.
           * @description
           * This function uses Electron's IPC (Inter-Process Communication) to send a request to the main process to remove all items from the context menu.
           * The IPC channel used is specified in `applicationBootstrap.channel_application_removeContextMenu`.
           * Any errors that occur during the execution are handled by the `handleError` function.
           */
          removeContextMenu: async function () {
              const channel = applicationBootstrap.channel_application_removeContextMenu;
              console.debug(`In $(applicationBootstrap.channel_application_removeContextMenu)`)
              const results = await ipcRenderer.invoke(channel);
              handleError(results?.error, channel);
              return results.value;
          },
          createDesktopTrayItem: async function(iconPath, menuTemplate, toolTip) {
              const channel = applicationBootstrap.channel_application_createTrayItem;
              console.debug(`In ${channel}`);
              const updatedTemplate = registerMenuClickFunctions(menuTemplate);
              const results = await ipcRenderer.invoke(channel, iconPath, updatedTemplate, toolTip);
              handleError(results?.error, channel);
              return results.value;
          },
          deleteDesktopTrayItem: async function() {
              const channel = applicationBootstrap.channel_application_deleteTrayItem;
              console.debug(`In ${channel}`);
              const results = await ipcRenderer.invoke(channel);
              handleError(results?.error, channel);
              return results.value;
          },
          customAlert: function(displayMsg, alertType) {
            const channel = applicationBootstrap.channel_application_customAlert;
            console.debug(`In ${channel}`);
            const results = ipcRenderer.sendSync(channel, displayMsg, alertType);
            if (results.error) {
                console.log('Error displaying alert:', results.error);
                return false;
              }
            return results.value;
          }
      }
  });